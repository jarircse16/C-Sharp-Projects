﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        bool isFirstRun = true;

        while (true)
        {
            if (isFirstRun)
            {
                DisplayHelpMessage();
                isFirstRun = false;
            }

            Console.WriteLine("Current Directory: " + Environment.CurrentDirectory);
            Console.Write("Enter the command (or 'q' to quit): ");
            string input = Console.ReadLine();

            if (input == "q")
                break;

            string[] command = input.Split(' ');
            string commandName = command[0].ToLower();

            switch (commandName)
            {
                case "cd":
                    if (command.Length < 2)
                    {
                        Console.WriteLine("Please provide a directory path.");
                        Console.WriteLine("Usage: cd <directory_path>");
                        continue;
                    }
                    string directoryPath = command[1];
                    ChangeDirectory(directoryPath);
                    break;
                case "dir":
                    ListDirectoryFiles();
                    break;
                case "search":
                    if (command.Length < 2)
                    {
                        Console.WriteLine("Please provide a file name to search.");
                        Console.WriteLine("Usage: search <file_name>");
                        continue;
                    }
                    string fileName = command[1];
                    SearchFile(fileName);
                    break;
                default:
                    Console.WriteLine("Invalid command.");
                    Console.WriteLine("Usage: cd <directory_path>");
                    Console.WriteLine("       dir");
                    Console.WriteLine("       search <file_name>");
                    break;
            }

            Console.WriteLine();
        }
    }

    static void DisplayHelpMessage()
    {
        Console.WriteLine("Welcome to the File Search program!");
        Console.WriteLine("This program allows you to search for files in the current directory, its subdirectories, and drive roots.");
        Console.WriteLine("Usage:");
        Console.WriteLine("cd <directory_path> - Changes the current directory to the specified directory path.");
        Console.WriteLine("dir - Lists the file names in the current directory and its subdirectories.");
        Console.WriteLine("search <file_name> - Searches for files with matching names in the current directory, its subdirectories, and drive roots.");
        Console.WriteLine();
    }

    static void ChangeDirectory(string directoryPath)
    {
        try
        {
            string path = Path.GetFullPath(directoryPath);

            if (Directory.Exists(path))
            {
                Environment.CurrentDirectory = path;
                Console.WriteLine("Directory changed to: " + Environment.CurrentDirectory);
            }
            else
            {
                Console.WriteLine("Directory not found.");
            }
        }
        catch (Exception)
        {
            Console.WriteLine("Invalid directory path.");
        }
    }

    static void ListDirectoryFiles()
    {
        try
        {
            Console.WriteLine("Files in current directory and its subdirectories:");
            RecursiveListDirectory(Environment.CurrentDirectory);
        }
        catch (Exception)
        {
            Console.WriteLine("Error occurred while listing directory files.");
        }
    }

    static void RecursiveListDirectory(string directoryPath)
    {
        try
        {
            string[] files = Directory.GetFiles(directoryPath);
            foreach (string file in files)
            {
                Console.WriteLine(Path.GetFileName(file));
            }

            string[] directories = Directory.GetDirectories(directoryPath);
            foreach (string directory in directories)
            {
                try
                {
                    RecursiveListDirectory(directory);
                }
                catch (UnauthorizedAccessException)
                {
                    // Ignore directories we don't have access to
                }
            }
        }
        catch (Exception)
        {
            // Ignore any errors while listing
        }
    }

    static void SearchFile(string fileName)
    {
        try
        {
            Console.WriteLine("Searching for files...");

            List<string> matchedFiles = new List<string>();

            if (IsDriveRoot(Environment.CurrentDirectory))
            {
                // Search the entire drive
                string drive = Environment.CurrentDirectory.Substring(0, 2);
                RecursiveSearch(drive, fileName, matchedFiles);
            }
            else
            {
                // Search within the current directory and its subdirectories
                RecursiveSearch(Environment.CurrentDirectory, fileName, matchedFiles);
            }

            if (matchedFiles.Count > 0)
            {
                Console.WriteLine("File(s) found:");
                foreach (string file in matchedFiles)
                {
                    Console.WriteLine(file);
                }
            }
            else
            {
                Console.WriteLine("File not found.");
            }
        }
        catch (Exception)
        {
            Console.WriteLine("Error occurred while searching for the file.");
        }
    }

    static bool IsDriveRoot(string path)
    {
        string root = Path.GetPathRoot(path);
        return path == root.TrimEnd(Path.DirectorySeparatorChar);
    }

    static void RecursiveSearch(string directoryPath, string fileName, List<string> matchedFiles)
    {
        try
        {
            string[] files = Directory.GetFiles(directoryPath, "*" + fileName + "*");
            foreach (string file in files)
            {
                matchedFiles.Add(file);
            }

            string[] directories = Directory.GetDirectories(directoryPath);
            foreach (string directory in directories)
            {
                try
                {
                    RecursiveSearch(directory, fileName, matchedFiles);
                }
                catch (UnauthorizedAccessException)
                {
                    // Ignore directories we don't have access to
                }
            }
        }
        catch (Exception)
        {
            // Ignore any errors while searching
        }
    }
}
